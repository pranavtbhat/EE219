### 
# EE219 - Project 4
###

### 
# Team Members 
###
Isha Verma            | Heenal Doshi        | Pranav Thulasiram Bhat 
ishaverma@cs.ucla.edu | heenald@cs.ucla.edu | pranavtbhat@cs.ucla.edu 
         404761131    | 004758927           | 704741684 

The following README contains the requirements and steps that are required to execute Project 4.
The structure of the folders have also be explained. 

### 
# Dependencies 
###
numpy 
matplotlib 
sklearn 
nlkt 

###
# Usage 
###
       
python part<qno>.py

<<<<<<< HEAD
<qno> : 1,2,3,4,5,6
=======
<qno> : 1,2,3,4,5,6
