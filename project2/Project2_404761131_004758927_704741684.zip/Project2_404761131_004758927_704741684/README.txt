### 
# EE239AS - Project 2 
###

### 
# Team Members 
###
Isha Verma            | Heenal Doshi        | Pranav Thulasiram Bhat 
ishaverma@cs.ucla.edu | heenald@cs.ucla.edu | pranavtbhat@cs.ucla.edu 
         404761131    | 004758927           | 704741684 

The following README contains the requirements and steps that are required to execute Project 2. 
The structure of the folders have also be explained. 

### 
# Dependencies 
###
numpy 
matplotlib 
sklearn 
nlkt 

###
# Usage 
###
       
python <qno>.py

<qno> : a, b, c, d, e, h, i-1, i-2
